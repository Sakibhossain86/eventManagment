import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { StudentEvents } from '../models/studnet-event.model';
//import { StudentEvents } from '../models/student-events.model';

@Injectable({
  providedIn: 'root'
})
export class StudentEventsService {
  private apiUrl = 'api/events'; // This matches the key returned by InMemoryDataService

  constructor(private http: HttpClient) {}

  // Get all events
  getEvents(): Observable<StudentEvents[]> {
    return this.http.get<StudentEvents[]>(this.apiUrl);
  }

  // Get single event by ID
  getEvent(id: string): Observable<StudentEvents> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.get<StudentEvents>(url);
  }

  // Create new event
  createEvent(event: StudentEvents): Observable<StudentEvents> {
    return this.http.post<StudentEvents>(this.apiUrl, event);
  }

  // Update existing event
  updateEvent(event: StudentEvents): Observable<StudentEvents> {
    const url = `${this.apiUrl}/${event.id}`;
    return this.http.put<StudentEvents>(url, event);
  }

  // Delete event
  deleteEvent(id: string): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.delete<void>(url);
  }
}
