import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Injectable } from '@angular/core';
import { EventCategory, EventStatus, StudentEvents } from '../models/studnet-event.model';

@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const events: StudentEvents[] = [
      {
        id: '1',
        title: 'Angular Workshop',
        description: 'Learn Angular basics',
        category: EventCategory.WORKSHOP,
        status: EventStatus.DRAFT,
        eventDate: new Date('2025-10-01'),
        createdAt: new Date(),
        attendees: 50,
        location: 'Southeast University, Permanent Campus, Room SEU613'
      }
    ];
    return { events };
  }
}
