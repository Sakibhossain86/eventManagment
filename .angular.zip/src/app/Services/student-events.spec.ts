import { TestBed } from '@angular/core/testing';
import { StudentEvents } from '../models/studnet-event.model';

//import { StudentEvents } from './student-events';

describe('StudentEvents', () => {
  let service: StudentEvents;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    //service = TestBed.inject(StudentEvents);
  });

  it('should be created', () => {
    //expect(service).toBeTruthy();
  });
});
