
export enum EventCategory {
    WORKSHOP = 'Workshop',
    SEMINAR = 'Seminar',
    SOCIAL = 'Social',
  CLUB = 'Club',
  MEETING = 'Meeting'
}

export enum EventStatus {
DRAFT = 'Draft',
  SCHEDULE = 'Schedule',
  ONGOING = 'Ongoing',
  COMPLETED = 'Completed',
  CANCELLED = 'Cancelled'
}

export interface StudentEvents {
  id: string;
  title: string;
  description: string;
  category: EventCategory;
  status: EventStatus;
  eventDate: Date;
  createdAt: Date;
  attendees: number;
  location: string;
}


