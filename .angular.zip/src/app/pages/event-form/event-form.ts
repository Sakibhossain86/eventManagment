import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EventCategory, EventStatus } from '../../models/studnet-event.model';
import { StudentEventsService } from '../../Services/student-events';

@Component({
  selector: 'app-event-form',
  standalone: false,
  templateUrl: './event-form.html',
  styleUrl: './event-form.scss'
})
export class EventForm {

  eventForm: FormGroup;
  categories = Object.values(EventCategory);
  statuses = Object.values(EventStatus);

  constructor(private fb: FormBuilder, private eventService: StudentEventsService) {
    this.eventForm = this.fb.group({
      title: ['', Validators.required],
      description: [''],
      category: ['', Validators.required],
      status: ['', Validators.required],
      eventDate: ['', Validators.required],
      location: ['', Validators.required],
      attendees: [0, [Validators.required, Validators.min(1)]]
    });
  }

  onSubmit(): void {
    if (this.eventForm.valid) {
      const newEvent = {
        ...this.eventForm.value,
        id: crypto.randomUUID(),
        createdAt: new Date()
      };
      this.eventService.createEvent(newEvent).subscribe(() => {
        alert('Event created successfully!');
        this.eventForm.reset();
      });
    }
  }

}
