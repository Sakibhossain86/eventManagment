import { Component, OnInit } from '@angular/core';
import { StudentEventsService } from '../../Services/student-events';
import { StudentEvents } from '../../models/studnet-event.model';

@Component({
  selector: 'app-event-list',
  standalone: false,
  templateUrl: './event-list.html',
  styleUrl: './event-list.scss'
})
export class EventListComponet implements OnInit {

 events: StudentEvents[] = [];
  loading = true;
  
  constructor(private eventService: StudentEventsService) {}

  ngOnInit(): void {
    this.eventService.getEvents().subscribe({
      next: (data) => {
        this.events = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error fetching events:', err);
        this.loading = false;
      }
    });
  }

}
