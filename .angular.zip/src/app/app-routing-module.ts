import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {  EventListComponet } from './pages/event-list/event-list';
import { EventForm } from './pages/event-form/event-form';

const routes: Routes = [
  { path: '', redirectTo: 'events', pathMatch: 'full' },
  { path: 'events', component: EventListComponet },
  { path: 'events/new', component: EventForm },
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
